package com.example.cameratestaplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    Camera camera;
    FrameLayout frameLayout;
    ShowCamera showCamera;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frameLayout = (FrameLayout)findViewById(R.id.frameLayout);

        //otvorime si cameru
        camera = Camera.open();
        showCamera = new ShowCamera(this, camera);
        frameLayout.addView(showCamera);
    }

    // Metoda pomocou ktorej dostaneme nas obrazok a budeme vediet ulozit alebo nejako spracovat nase data
    Camera.PictureCallback ourPictureCallback = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            File newPicture = getPictureFile();
            if (newPicture == null){
                return;
            }
            else{
                try{
                    FileOutputStream fOs = new FileOutputStream(newPicture);
                    fOs.write(data);
                    fOs.close();

                    camera.startPreview();
                }
                catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
    };

    //Ulozenie obrazku
    private File getPictureFile(){
        String state  = Environment.getExternalStorageState();
        if (!state.equals(Environment.MEDIA_MOUNTED)){
            return null;
        }
        else{
            File folder = new File(Environment.getExternalStorageDirectory() + File.separator + "GUI");
            if (!folder.exists()){
                folder.mkdirs();
            }
            File outputPicture = new File(folder, "temp.jpg");
            return outputPicture;
        }
    }

    // Urobime zaznamenanie
    public void capturingImage(View view){
        if (camera != null){
            camera.takePicture(null, null, ourPictureCallback);
        }
    }

}